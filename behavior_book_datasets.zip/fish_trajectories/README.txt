
This dataset was originally obtained from the Fish4Knowledge project http://groups.inf.ed.ac.uk/f4k/GROUNDTRUTH/BEHAVIOR/

Files:

- "fishDetections_total3102.mat" contains the raw trajectories data.
- "fishFeatures.csv" contains the extracted features. See the script extract_features.R from the "Detecting Abnormal Behaviors" book chapter.


Original paper:

C. Beyan, R. B. Fisher, (2013), Detection of Abnormal Fish Trajectories Using a Clustering Based Hierarchical Classifier, British Machine Vision Conference (BMVC), Bristol, UK.
